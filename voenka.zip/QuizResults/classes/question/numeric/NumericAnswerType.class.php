<?php

class NumericAnswerType
{
    const BETWEEN           = 'between';
    const EQUAL             = 'equal';
    const GREATHER          = 'greather';
    const GREATHER_OR_EQUAL = 'greatherOrEqual';
    const LESS              = 'less';
    const LESS_OR_EQUAL     = 'lessOrEqual';
    const NOT_EQUAL         = 'notEqual';
}