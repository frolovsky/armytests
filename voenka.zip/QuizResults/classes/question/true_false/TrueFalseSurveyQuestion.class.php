<?php

class TrueFalseSurveyQuestion extends MultipleChoiceSurveyQuestion
{

}